#!/bin/sh


killall -HUP clloader
killall -TERM clloader

